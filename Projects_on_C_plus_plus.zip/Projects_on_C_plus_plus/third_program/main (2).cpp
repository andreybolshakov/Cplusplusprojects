#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;
int main() {
	int i, j, n,**A,p,sum;
	bool isNegative = false;
	bool isAnyPosit = false;
	setlocale(LC_ALL, "Russian");
	while (1)
	{
		printf("\nВведите размерность матрицы:");
		while (!(cin >> n))
		{
			cin.clear();
			while (cin.get() != '\n');
			system("cls");
			cout << "Неверный ввод. Повторите: ";
		}
		if (n > 0) {
			break;
		}
		else {
			system("cls");
			printf("Неверный ввод. Повторите: ");
		}

	}
	system("cls");
	p = 1;
	sum = 0;
	srand(time(NULL));
	A= new int *[n];
	for (i = 0; i < n; i++)
	{
		isNegative = false;
		A[i] = new int[n];
		for (j = 0; j < n; j++)
		{
			printf("A[%d][%d]=> ", i, j);
			scanf("%d", &A[i][j]);
			if (A[i][j] <= 0)
				isNegative = true;
		}
		if (!isNegative)
		{
			for (j = 0; j < n; j++)
				p *= A[i][j];
			isAnyPosit = true;
		}
		std::cout << "\r\n";
	}
	printf("Исходная квадратная матрица.\n");
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%4.d", A[i][j]);
		}
		printf("\n");
	}
	for (i = 0; i < n; i++)
		for (j = i + 1; j < n - ((i == 0) ? 1 : 0); j++)
			sum += (A[i][j] + A[j][i]);
	if (isAnyPosit)
		std::cout << "Произведение : " << p << "\r\n";
	else
		std::cout << "Матрица не содержит строк которые не содержат отрицательных\r\n";
	std::cout << "Сумма : " << sum << "\r\n";
	cin.get();
	cin.get();
	return 0;
}