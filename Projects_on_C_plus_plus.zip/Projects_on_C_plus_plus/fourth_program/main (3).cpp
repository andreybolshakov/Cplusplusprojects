#include <conio.h>
#include <iostream>
#include<windows.h>
using namespace std;
struct Aeroflot
{
	char punkt_naznachenia[40];
	int nomer_reisa;
	char tip_samoleta[20];
};
int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	Aeroflot as[7];
	int i = 0, kol = 7;
	setlocale(LC_ALL, "Russian");

	for (i = 0; i < kol; i++) {
		cout << i + 1 << "-ая запись " << endl;
		cout << "Введите название пункта назначения(не более 40 символов)" << endl;
		cin >> as[i].punkt_naznachenia;
		cout << "Введите номер рейса " << endl;
		cin >> as[i].nomer_reisa;
		cout << "Введите тип самолета(не более 20 символов) " << endl;
		cin >> as[i].tip_samoleta;
	}

	int temp;
	for (i = 0; i < kol; i++) {
		if (as[i].nomer_reisa > as[i + 1].nomer_reisa) { temp = as[i].nomer_reisa; as[i].nomer_reisa = as[i + 1].nomer_reisa; as[i].nomer_reisa = as[i + 1].nomer_reisa = temp; continue; }
		cout << "Вывод записей " << endl;

		for (i = 0; i < kol; i++) {
			cout << as[i].punkt_naznachenia << " ";
			cout << as[i].nomer_reisa << " ";
			cout << as[i].tip_samoleta << endl;
		}

		char poisk_samoletov[40];
		cout << "Пункт назначения рейса " << endl;
		cin >> poisk_samoletov;
		bool f = false;
		for (i = 0; i < kol; i++)
			if (strcmp(as[i].punkt_naznachenia, poisk_samoletov) == 0)
			{
				cout << "Номер рейса ";
				cout << as[i].nomer_reisa << endl;
				cout << "Тип самолета ";
				cout << as[i].tip_samoleta << endl;
				f = true;
			}
		if (!f) {
			cout << "Нет такого пункта назначения рейса " << endl;
		}
		_getch();
	}
	return 0;
}