#include <iostream>
#include <conio.h>
#include <cstdlib>
#include <math.h>
#include <stdio.h>
using namespace std;
int main() 
{
    	setlocale(LC_ALL, "Russian");
	float a, b, c, Xn, Xk, dX,F;
	int i;

	printf("Введите a:");
	scanf("%f", &a);
	system("cls");
	printf("Введите b:");
	scanf("%f", &b);
	system("cls");
	printf("Введите c:");
	scanf("%f", &c);
	system("cls");
	printf("dВведите Xнач.:");
	scanf("%f", &Xn);
	system("cls");
	printf("Введите Xкон.:");
	scanf("%f", &Xk);
	system("cls");
	printf("Введите dX:");
	scanf("%f", &dX);
	system("cls");
	printf("\n\n  X     F\n");
	if ((floor(c) < 0) && (Xn != 0))
		for (i = Xn; i <= Xk; i += dX) 
		{    F=-a*i-c;
	printf("\n  %d  %5.2f",i,F); 
		}
	if ((floor(c) > 0) && (Xn == 0))
		for (i = Xn; i <=Xk; i += dX) { 
			 F = ((i-a)/(-c));
			printf("\n  %d  %5.2f", i, F);
		}
	else
		for (i = Xn; i <= Xk; i += dX) {
		   F = floor((b*i)/(c-a));
		   printf("\n  %d  %5.0f", i, F);
		}
	cin.get();
	cin.get();
	return 0;
}