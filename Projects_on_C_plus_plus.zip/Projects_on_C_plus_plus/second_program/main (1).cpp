#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#define N 100
using namespace std;
int main()
{
	int i, n,r,t;
	float A[N],sum=0,sum1=0;
	setlocale(LC_ALL, "Russian");
	printf("\nВведите размерность вектора:");
	while (1)
	{
		while (!(cin >> n))
		{
			cin.clear();
			while (cin.get() != '\n');
			system("cls");
			cout << "Неверный ввод. Повторите: ";
		}
		if (n > 0) {
			break;
		}
		else {
			system("cls");
			printf("Неверный ввод. Повторите: ");
		}

	}
	system("cls");
	printf("Введите вектор.\n");
	for (i = 0; i < n; i++)
	{
		printf("A[%d]=> ", i);
		scanf("%f", &A[i]);
	}
	system("cls");
	printf("Исходный вектор.\n");
	for (i = 0; i < n; i++)
	{
		printf("%5.2f", A[i]);
	}
	for (int i = 0; i <n; i+=2) {
			sum += A[i];
	}
	printf("\nСумма элементов массива с нечетными номерами: %5.2f\n", sum);
	for (i = 0; i < n; i++) {
		if (A[i] < 0) {
			r = i;
			break;
		}
	}
	for (i = 0; i < n; i++) {
		if (A[i] < 0)
			t = i;
	}
	for (i = r + 1; i < t; i++) sum1 += A[i];
	printf("Сумма элементов массива расположенных между первым и последним отрицательным элементом: %5.2f\n", sum1);
	for (int i = 0; i < n; i++)
	{
		if (abs(A[i]) < 1) A[i] = 0;
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (A[i] == 0)
			{
				A[i] = A[j];
				A[j] = 0;
			}
			else break;
		}
	}
	printf("Измененный вектор.\n");
	for (i = 0; i < n; i++)
	{
		printf("%5.2f", A[i]);
	}
	cin.get();
	cin.get();
	return 0;

}